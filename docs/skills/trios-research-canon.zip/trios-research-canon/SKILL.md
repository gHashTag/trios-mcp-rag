---
name: trios-research-canon
description: "Literature canon backing the trios-mcp-rag operating rules: 4-track research synthesis across (1) TRIOS / S³AI / GOLDEN BRIDGE and adjacent neuro-symbolic / self-supervised reasoning work, (2) RAG over SSOT / structured Postgres sources (Lewis 2020, GraphRAG, RAGAS, pgvector hybrid retrieval, text-to-SQL), (3) claim-status, calibration, and falsifiability for LLM outputs (TruthfulQA, FActScore, FELM, HaluEval, Popperian framing, abstention policies), and (4) reproducible scholarly PDF pipelines (pandoc, tectonic, Quarto, Typst, figure-placement and PDF/UA-2 accessibility literature). Load when answering questions about why a TRIOS rule exists, drafting a new chapter that needs external citation anchoring, evaluating a claim's epistemic status, designing a RAG evaluation harness, or justifying a build / typography decision for the GOLDEN CHAIN PDF. Companion to the trios-mcp-rag skill, which carries the normative rules."
metadata:
  source_repo: https://github.com/gHashTag/trios-mcp-rag
  compiled: '2026-05-29'
  tracks: 4
  word_count: 6027
  version: '1.2.5'
  changelog: "1.2.5 — 2026-05-29 round-6 next-wave + Track 1 legacy verify + cross-cutting verify + 2026 NeSy/PDF sweep. Zero anomalies in Track 1 refs 5–8 (SymAgent author order, Delvecchio IJCAI 2025 venue, Honda & Hagiwara Neurocomputing 654 (2025) 131269 via scik.org bibliography fallback after Elsevier IP block, Wan ISPASS 2024 title re-confirmed) and zero anomalies in 05-cross-cutting.md (internal pointers only, no external citations). Added 1 next-wave reference: (T1 ref 9) Sultan, Thuraisamy, Rajaratnam arXiv:2605.17596 'NeuSymMS: A Hybrid Neuro-Symbolic Memory System for Persistent, Self-Curating LLM Agents' (cs.AI, 2026-05-17) — closest 2026 production-NeSy parallel to TRIOS: subject–relation–value triples in RDBMS as the symbolic layer, LLM neural fact extraction, CLIPS expert system with explicit lifecycle rules (classification, deduplication, reconciliation, access-based promotion, time-based pruning), user / agent / agent-to-agent scoping. Anomaly guard: NeuSymMS abstract mentions REMem baseline numbers (3.4% / 13.4%); those belong to REMem and were deliberately omitted from the canon entry. 2026 PDF pipeline sweep returned no canon-worthy candidates beyond Tan & Rigger ISSTA 2024, Maedje 2024, and the existing Overleaf / eSAIL PDF/UA-2 anchors. Canon size: T1 8→9, T2=20, T3=15, T4=11, cross-cutting=9 recs, total 55 references. 1.2.4 — 2026-05-29 round-5 next-wave + Track 4 re-verify. Fixed 1 anomaly: (T4) Mittelbach TUGboat 2018 title — 'Managing forlorn orphans and widows' (paraphrase) corrected to verbatim 'Managing forlorn paragraph lines (a.k.a. widows and orphans) in LaTeX', added page range 246–251. Added 3 next-wave references: (T2 ref 19) Budigi & Sirigiri arXiv:2605.03275 'Beyond Similarity Search: A Unified Data Layer for Production RAG Systems' — controlled benchmark on 50k docs, 92% latency reduction on date-filtered queries, 74% on tenant-scoped, 93% less sync code; direct empirical backing for the single-Postgres pgvector+HNSW stance; (T2 ref 20) Sun et al. arXiv:2605.05253 'EnterpriseRAG-Bench: A RAG Benchmark for Company Internal Knowledge' — 500k docs across nine enterprise sources with 500 questions and a 'recognising when information is absent' category that maps onto the TRIOS abstention policy; (T3 ref 15) Atasoy, Mutlu, Sezer, Wahdan arXiv:2605.08462 'Do Benchmarks Underestimate LLM Performance?' (ROMCIR Workshop at ECIR 2026) — LLM-first + human-adjudicated re-evaluation: triple agreement +6.38% (QAGS-C) / +7.62% (SummEval), adjudicators frequently sided with model judgments over original human labels when LLMs gave explicit reasoning. MacFarlane TUG 2020 talk, Tan & Rigger ISSTA 2024, Maedje 2024 — verified against primary sources, no fix needed. 1.2.3 — 2026-05-29 round-4 audit of Track 2/3 legacy entries not touched in round 3. Fixed 5 citation anomalies: (T2) KAG arXiv:2409.13731 — full title restored to 'KAG: Boosting LLMs in Professional Domains via Knowledge Augmented Generation'; (T2) RAGONITE arXiv:2412.17690 — full title restored to '...for Conversational QA over KGs with RAG'; (T3) FELM arXiv:2310.00741 — author label 'Chern et al.' corrected to 'Chen, Zhao, Zhang, Chern et al.' (Shiqi Chen is first author, I-Chun Chern is 4th), AND the 48.3% claim reformulated as 'segment-level F1 in the most favourable setting (Table 4, Content F1)' rather than an implied overall benchmark score; (T3) POPPER OpenReview iTevNo8PzG — full rewrite: title 'Automated Hypothesis Validation with Agentic Sequential Falsifications', authors Huang/Jin/R.Li/M.Y.Li/Candes/Leskovec, venue ICML 2025 poster, '10× faster' restated as '10 folds' per arXiv abstract. Verified verbatim against primary sources: HaluEval 30,000 samples, TruthfulQA 58% truthfulness, Tomani 50% hallucination reduction, CoRE +17.2% on hard tasks. No new references added. 1.2.2 — 2026-05-29 round-3 audit covering zones round 2 did not touch (Track 1 adjacent NeSy, Track 4 PDF pipeline, legacy Track 2/3 entries, synthesis paragraphs). Fixed 7 citation anomalies: (T1) Platzer arXiv:2406.11563 — removed fabricated 'IJCAI 2024' venue; (T1) Renkhoff arXiv:2401.03188 — added DOI 10.1109/TAI.2024.3351798 and corrected title to '...Neurosymbolic Artificial Intelligence'; (T1) Wang Imperative Learning year (2025) → (IJRR 2025; arXiv v1 Jun 2024); (T1) Delvecchio/Molfetta/Moro IJCAI 2025 — corrected fabricated 'Disi-UNIBO' authorship to real author names, added full title 'Neuro-Symbolic Artificial Intelligence: A Task-Directed Survey in the Black-Box Models Era', confirmed Survey Track; (T1) Wan ISPASS 2024 title — 'Workload Characterization' → 'Workload AND Characterization'; (T2) ConstraintLLM EMNLP 2025 — first author Zhang → Shi, full title with 'Industrial-Level', clarified CARM = Constraint-Aware Retrieval Module; (T3) Xu et al. 'Hallucination is Inevitable' year 2025 → 2024 (v1 22 Jan 2024). Tan & Rigger 0.2%/42.1% statistics verified verbatim against abstract. Next-wave scan: no foundational gaps; ConRAG/ArchRAG/GRASP/TruthRL are application-level follow-ups, not canon-worthy. 1.2.1 — 2026-05-29 audit follow-up: round-2 anomaly hunt (64-URL re-extraction, 100% link liveness after HEAD→GET fallback, content-verified every new Track 2/3 reference against arXiv). Fixed 4 citation errors introduced in v1.2: RAGEval year 2025→2024 (arXiv 2408 = Aug 2024); HaystackCraft actual paper title is 'Haystack Engineering: Context Engineering for Heterogeneous and Agentic Long-Context Evaluation' (HaystackCraft is the benchmark name); ONERULER actual title is 'One ruler to measure them all: Benchmarking multilingual long-context language models'; CHOKE actual title is 'Trust Me, I am Wrong: LLMs Hallucinate with Certainty Despite Knowing the Answer' and CHOKE acronym expanded to 'Certain Hallucinations Overriding Known Evidence'. Added missing venues: RULER (COLM 2024), NoLiMa (ICML 2025). No new references added; canon size unchanged. 1.2 — 2026-05-29 literature refresh: 47-URL link audit (45 OK, 2 transient non-blocking); +8 RAG 2024–2025 papers (RULER, RAGBench, ARES, RAGEval, CoFE-RAG, HaystackCraft, NoLiMa, ONERULER) in Track 2 with new long-context / multilingual / distractor-robustness synthesis paragraph and 3 new rule-file recommendations; +4 calibration / factuality references (FACTS Grounding arXiv:2501.03200, FACTS Benchmark Suite, Behaviorally Calibrated RL arXiv:2512.19920, CHOKE arXiv:2502.12964) in Track 3 with 2 new rule-file recommendations; +1 PDF reproducibility reference (Tan & Rigger ISSTA 2024 arXiv:2407.15511, empirical 0.2% XeTeX/PDFTeX and 42.1% cross-version identical-output rates) in Track 4 with a new tectonic version-pin rule recommendation. 1.1 — added two cross-cutting recommendations driven by the 2026-05-29 GOLDEN CHAIN audit: (a) coverage / freshness as build-time SQL gates (linking Track 2 RAGAS context-recall and Track 3 FActScore atomic-check to rule 09.1 / 09.2), and (b) accessibility metadata as a schema-level CHECK constraint (linking Track 4 PDF/UA-2 literature to rule 09.3). 1.0 — initial 4-track canon."
---

# trios-research-canon — Literature Backing for trios-mcp-rag

This skill is the **literature canon** behind the operating rules of
[gHashTag/trios-mcp-rag](https://github.com/gHashTag/trios-mcp-rag).
It is paired with the **`trios-mcp-rag`** skill, which carries the
normative rules; this skill carries the *why* — the peer-reviewed and
practitioner evidence supporting those rules.

## When to Use This Skill

Load this skill when you need to:

- justify or challenge a rule in `trios-mcp-rag` with cited evidence
- draft a new chapter or PDF section that needs external-citation
  anchoring (Track 1 + Track 3 requirement: no external DOI ⇒ capped at
  Open conjecture)
- design or revise the RAG evaluation harness for `ssot_brochure.chapters`
  (Track 2: RAGAS, GraphRAG, hybrid retrieval)
- evaluate the epistemic status of a claim and pick the right label
  (Track 3: Verified / Empirical fit / Open conjecture / High-risk /
  Retracted, mapped to HaluEval and FActScore taxonomies)
- justify a build, typography, or accessibility decision for the
  GOLDEN CHAIN PDF (Track 4: pandoc / tectonic / Quarto / PDF/UA-2)
- explain to a collaborator why a specific QA gate exists or why a
  proposed shortcut would violate the canon

For the rules themselves and the Quickstart that connects the project
to Claude Code, use the **`trios-mcp-rag`** skill instead.

## How the Canon Is Organised

The full report is in `references/canon-full.md` (≈4,100 words, single
file). It is also split per track for targeted retrieval:

- `references/00-overview.md` — purpose and scope of the canon.
- `references/01-trios-s3ai-adjacent.md` — **Track 1.** A direct
  arXiv / Google Scholar / Semantic Scholar / OpenReview search for
  "TRIOS", "S³AI", "GOLDEN BRIDGE", and `gHashTag` returned **zero
  peer-reviewed publications** as of 2026-05-29. The track instead
  surfaces 9 high-signal adjacent references on neuro-symbolic AI,
  self-supervised reasoning, knowledge-grounded LLMs, and
  textbook-scale AI compendium generation, and explains why each
  applies to this project. **Added v1.2.5 (2026):** Sultan,
  Thuraisamy, Rajaratnam arXiv:2605.17596 'NeuSymMS' — hybrid
  neuro-symbolic memory with subject–relation–value triples in RDBMS,
  CLIPS expert system, dual-horizon memory under explicit lifecycle
  rules; closest 2026 production-NeSy parallel to the TRIOS
  architecture.
- `references/02-rag-over-ssot.md` — **Track 2.** 18 references
  (v1.2 +8). Foundational: Lewis et al. (NeurIPS 2020), Microsoft
  GraphRAG (arXiv 2404.16130), RAGAS (EACL 2024), pgvector hybrid
  retrieval practitioner guides, KAG, Datrics Text2SQL,
  ConstraintLLM. **Added v1.2 (2024–2025):** RULER (arXiv:2404.06654),
  RAGBench (arXiv:2407.11005), ARES (arXiv:2311.09476), RAGEval
  (arXiv:2408.01262), CoFE-RAG (arXiv:2410.12248), HaystackCraft
  (arXiv:2510.07414), NoLiMa (arXiv:2502.05167), ONERULER
  (arXiv:2503.01996) — long-context evaluation, multilingual
  benchmarks, distractor robustness, and full-chain evaluation.
- `references/03-claim-status-calibration.md` — **Track 3.** 14
  references (v1.2 +4). Foundational: TruthfulQA (ACL 2022), FActScore
  (EMNLP 2023), FELM (NeurIPS 2023), HaluEval (EMNLP 2023), Xu et al.'s
  hallucination-is-inevitable result, Tomani's abstention policy paper,
  I-CALM, Popper (1963), POPPER agentic validation. **Added v1.2
  (2025–2026):** FACTS Grounding Leaderboard (arXiv:2501.03200), FACTS
  Benchmark Suite (Google DeepMind 2025, 4-pillar factuality, Gemini
  3 Pro tops at 68.8%), Behaviorally Calibrated RL (arXiv:2512.19920),
  and the CHOKE counter-finding on high-certainty hallucinations
  (arXiv:2502.12964). The track maps the TRIOS five-level scheme
  (Verified / Empirical fit / Open conjecture / High-risk / Retracted)
  onto the HaluEval taxonomy and the FActScore rubric.
- `references/04-reproducible-pdf-pipeline.md` — **Track 4.** 11
  references (v1.2 +1). Foundational: pandoc docs, MacFarlane TUG
  2020, tectonic book + GitHub reproducibility discussion, Quarto
  figure docs, Mittelbach TUGboat 2018 (widows / orphans / penalties),
  TeX FAQ, Overleaf / eSAIL PDF/UA-2 guides, Maedje's TeX-vs-Typst
  layout analysis. **Added v1.2:** Tan & Rigger ISSTA 2024
  (arXiv:2407.15511) — empirical 0.2% XeTeX/PDFTeX and 42.1%
  cross-TeX-Live identical-output rates, backing the tectonic
  version-pin rule.
- `references/05-cross-cutting.md` — **9 cross-cutting
  recommendations** that tie all four tracks back to specific rule
  files (`00-canonical-pipeline.md`, `01-ssot-and-derived-artifacts.md`,
  `02-pdf-style.md`, `03-safety-railway-postgres.md`,
  `04-claim-status.md`, `05-brochure-qa-checklist.md`,
  `06-language-policy.md`, `trios-phd-canon.md`,
  `IMAGE_PLACEMENT.md`, `IMAGE_MANIFEST_SCHEMA.md`,
  `PDF_QA_CHECKLIST.md`).
- `references/canon-full.md` — the full single-file canon.

## Headline Findings (TL;DR)

1. **TRIOS / S³AI / GOLDEN BRIDGE has no external peer-reviewed
   footprint** as of 2026-05-29. The repo cannot rely on its brand
   names for credibility — every algorithmic or empirical claim must
   cite an external DOI from a recognised venue, otherwise it is
   capped at **Open conjecture**.
2. **Hybrid pgvector HNSW + tsvector GIN inside a single Postgres
   instance is production-grade for SSOT-backed RAG.** The existing
   read-only default plus an index-presence pre-build check is enough;
   no external vector store is required.
3. **Hallucinations are provably unavoidable** in the general case
   (Xu et al.). The right response is not "eliminate" but
   *label + abstain + falsification path*. Every Open-conjecture claim
   must carry a written disconfirming observation in the
   `falsification_path` column.
4. **Reproducible PDF builds require neutralising `CreationDate`
   non-determinism and pinning tectonic.** Add a `sha256` of the
   output PDF to the build log; treat a tectonic version bump as a
   pipeline change.
5. **`TRIOS_PHD_NO_IMAGE_TRAIN` is correct, but the implementation
   must be penalty-based**, not `\clearpage`-based:
   `\widowpenalty=9999`, `\clubpenalty=9999`, `\needspace{}` guards,
   and `fig-pos: 'ht'` in YAML. Combined with non-nullable `alt_text`
   in the image manifest, this also satisfies PDF/UA-2 accessibility.

## How to Apply the Canon

When reasoning about a TRIOS task:

1. Identify which track(s) the task touches.
2. Read the matching `references/0X-*.md` file before drafting an
   answer or a build command.
3. Cite the source in your response (use the inline links already in
   the canon — never bare URLs).
4. If the task creates or modifies a claim, pick a label from the
   five-level scheme and, if **Open conjecture**, write the
   falsification path immediately.
5. If the task changes the build pipeline, cross-check against the
   cross-cutting recommendations in `references/05-cross-cutting.md`
   before proposing the change.

## Relationship to Other Skills

- **`trios-mcp-rag`** — the normative rule set. Always load it for any
  TRIOS task. This skill (`trios-research-canon`) is the evidence base
  behind those rules; load it when justifying a decision or writing
  new material.
- **`research-assistant`** (built-in) — use for fresh literature
  searches on topics not yet covered in this canon. Add new findings
  back into `references/literature/` when they are substantive.

*Canon compiled 2026-05-29; refreshed 2026-05-29 (v1.2 audit — 47-URL
link check + 13 new 2024–2025 references across Tracks 2, 3, 4).
Track 1 negative result is dated; re-verify before citing as evidence
in any public artefact.*
