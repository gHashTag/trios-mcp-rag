---
name: trios-mcp-rag
description: "Operating rules for AI agents working on the trios-mcp-rag repository or the GOLDEN BRIDGE / TRIOS S³AI compendium. Use when generating, rebuilding, or replacing any PDF, brochure, article, or README derived from the TRIOS PhD pipeline; when touching anything labelled SSOT, ssot_brochure.*, ssot.*, or the Railway Postgres database; when proposing changes to the build pipeline (build_pdf tool, pipeline.rs, templates, Lua filters); when writing claims about results, prizes, falsifiability, or validation status; or when running the Quickstart that connects trios-mcp-rag to Claude Code and prints a GOLDEN CHAIN PDF."
metadata:
  source_repo: https://github.com/gHashTag/trios-mcp-rag
  source_files: AGENTS.md, CLAUDE.md, docs/agent-rules/, docs/qa/, docs/rag/
  version: '1.2'
  changelog: "1.2 — added rule 08 (MCP server registration: `-s user` global scope, absolute paths, no piped `claude mcp add`, reset both scopes before re-adding, restart session after register). 1.1 — added literature-grounded refinements (RAGAS gate, falsification_path, alt_text non-null, tectonic pinning, no-image-train via penalty) and references/literature/ folder with 4-track research canon."
---

# trios-mcp-rag — Operating Rules

This skill imports the canonical operating rules from
[gHashTag/trios-mcp-rag](https://github.com/gHashTag/trios-mcp-rag)
(`AGENTS.md` + `CLAUDE.md` + `docs/agent-rules/`) so any AI agent working on
that repository or its derived artefacts (GOLDEN BRIDGE / TRIOS S³AI
compendium, GOLDEN CHAIN PDF, brochures, articles, README) follows the
same hard rules outside Claude Code.

## When to Use This Skill

Load this skill before:

- generating, rebuilding, or replacing any PDF, brochure, article, or README
  derived from the GOLDEN BRIDGE / TRIOS S³AI compendium
- touching anything labelled "SSOT", `ssot_brochure.*`, `ssot.*`, or the
  Railway Postgres database
- proposing changes to the build pipeline (`build_pdf` tool, `pipeline.rs`,
  templates, Lua filters)
- writing claims about results, prizes, falsifiability, or validation status
- running the Quickstart that connects `trios-mcp-rag` to Claude Code and
  prints a new GOLDEN CHAIN PDF

The contents of `references/` are normative. When a rule below conflicts
with anything in chat, the rule wins unless the user explicitly overrides
it in the current session **for this specific change** — defaults do not
change without an explicit instruction.

## Hard Rules (Summary)

1. **Do not replace the Rust pandoc+tectonic pipeline with a Python /
   ReportLab / wkhtmltopdf / generic-text path.** `trios-phd` is a
   visual PhD renderer with embedded images and ornamental panels.
2. **The SSOT is the Postgres `ssot_brochure.chapters` (or `ssot.chapters`)
   table on Railway.** Files in the repo and in derived outputs are not
   authoritative; treat them as render targets.
3. **Default to read-only.** Writes require a written backup-and-rollback
   plan plus a dry-run plus an explicit human "go ahead" in the same
   session. No exceptions for "small fixes".
4. **Never print or commit DSNs, Railway tokens, passwords, or any value
   from `DATABASE_URL` / `RAILWAY_SSOT_URL`.** Reference them by env-var
   name only.
5. **Use claim-status framing** for any scientific or empirical statement
   (Verified / Empirical fit / Open conjecture / High-risk / Retracted).
   No hype, no prize / Nobel claims as deliverables — only as long-term
   external-validation standards.
6. **Run the QA checklist** before declaring a brochure / PDF build done
   (see `references/05-brochure-qa-checklist.md` and the operational form
   in `references/qa-brochure-pdf-checklist.md`).
7. **Public-facing repo content is English** unless the user requests
   otherwise for that specific artefact. Chat with the maintainer may be
   Russian.
8. **`TRIOS_PHD_NO_IMAGE_TRAIN`** — hero / context images are required on
   chapter openers, but they must be **semantically anchored** to a
   nearby substantive heading and body text. Do **not** print heroes as
   a gallery or back-to-back train of image-dominant pages. Enforce this
   with a **soft keep-together** rule for the *section heading + hero /
   context block + first paragraph(s)* group, not with a hard `\clearpage`
   before every section.

If you cannot satisfy a rule, stop and report. Do not silently relax it.

## Literature-Grounded Refinements (v1.1)

These refinements come from the research canon in
`references/literature/` (4-track review, May 2026). They extend, not
replace, the hard rules above. The full citations and synthesis are in
the matching literature file.

1. **RAGAS CI gate** — keep a versioned 20-question probe set in the
   repo and run RAGAS (faithfulness ≥ 0.80, context recall ≥ 0.75) as a
   build gate, alongside `pdfinfo` / `qpdf`. See
   `references/literature/02-rag-over-ssot.md`.
2. **`falsification_path` is mandatory for every Open conjecture.** A
   build that contains an Open-conjecture claim without a written
   disconfirming observation fails QA. See
   `references/literature/03-claim-status-calibration.md`.
3. **Adjacent-literature anchoring.** Track 1 confirms no peer-reviewed
   publication exists under TRIOS / S³AI / GOLDEN BRIDGE as of
   2026-05-29. Any new chapter making an algorithmic or empirical claim
   must cite at least one external DOI from a recognised venue;
   chapters without such citation are capped at Open conjecture
   regardless of narrative framing. See
   `references/literature/01-trios-s3ai-adjacent.md`.
4. **Index hygiene pre-build.** Abort the build if `pgvector` HNSW or
   `tsvector` GIN indexes on `ssot_brochure.chapters` are missing or
   stale — do not silently degrade retrieval. Read-only default
   remains in force.
5. **Epistemic-label propagation.** The Lua filter must emit
   claim-status markers verbatim into the LaTeX stream; downstream
   FActScore / RAGAS QA depends on labels surviving the
   Markdown → LaTeX hop.
6. **`alt_text` is non-nullable** in the image manifest. This is both a
   PDF/UA-2 accessibility requirement and the data-layer enforcement
   of `TRIOS_PHD_NO_IMAGE_TRAIN`.
7. **No-image-train via penalty, not `\clearpage`.** Use
   `\widowpenalty=9999`, `\clubpenalty=9999`, `\needspace{}` guards on
   chapter openers, and `fig-pos: 'ht'` in YAML. Hard `\clearpage`
   before every section is explicitly prohibited (it produces short
   title-only pages — a known regression).
8. **Tectonic version pinning.** Pin tectonic in `Cargo.toml` / CI.
   Treat a tectonic upgrade as a pipeline change requiring full QA
   re-run, not a routine dependency bump. Add `sha256` of the output
   PDF to the build log for reproducible-build checks.
9. **Extended language scan.** The QA scan must flag (a) non-English
   claim-status markers in public artefacts and (b) internal
   inconsistency where a claim labelled Open conjecture uses strong
   assertion language ("proves", "demonstrates conclusively").

For full rationale and citations of each refinement, see
`references/literature/05-cross-cutting.md`.

## Further Reading (Research Canon)

Full 4-track research canon (≈4,100 words) lives in
`references/literature/`:

- `00-overview.md` — purpose and scope.
- `01-trios-s3ai-adjacent.md` — TRIOS / S³AI / GOLDEN BRIDGE search
  result (no peer-reviewed hits) + adjacent neuro-symbolic and
  self-supervised reasoning literature.
- `02-rag-over-ssot.md` — foundational RAG (Lewis et al. 2020),
  GraphRAG, RAGAS, pgvector hybrid retrieval, text-to-SQL over KBs,
  long-context chunking.
- `03-claim-status-calibration.md` — TruthfulQA, FActScore, FELM,
  HaluEval, hallucination-inevitability proofs, abstention policies,
  Popperian falsifiability framing.
- `04-reproducible-pdf-pipeline.md` — pandoc, tectonic, Quarto, Typst,
  ConTeXt, figure-placement literature, PDF/UA-2 accessibility,
  reproducible-build practice.
- `05-cross-cutting.md` — 9 cross-track recommendations mapped to
  specific rule files.
- `canon-full.md` — single-file copy of the entire canon.

For deeper synthesis use the companion skill **`trios-research-canon`**.

## Reference Index

Read the relevant file from `references/` before acting in that domain:

- `references/00-canonical-pipeline.md` — Rust `trios-phd` / TRIOS MCP →
  Railway/Postgres SSOT → Markdown → pandoc → LaTeX → tectonic → PDF.
  The only supported renderer.
- `references/01-ssot-and-derived-artifacts.md` — Postgres is the SSOT.
  README, articles, brochures, PDFs are derived.
- `references/02-pdf-style.md` — White academic title page, serif
  typography, black-and-white engraved S³AI hero panels, book margins,
  large images. No teal/black corporate covers without an explicit
  one-shot request.
- `references/03-safety-railway-postgres.md` — Read-only by default.
  No writes without backup-first plan, dry-run, and explicit human
  confirmation. No DSN / token / password leakage.
- `references/04-claim-status.md` — Verified / Empirical fit / Open
  conjecture / High-risk / Retracted. No prize or Nobel claims as
  outcomes; only as long-term external-validation standards.
- `references/05-brochure-qa-checklist.md` — Pre-publish QA: duplicate
  sections, stale markers, style drift, secret scan, language scan,
  `qpdf` / `pdfinfo` / `pdftotext` checks.
- `references/08-mcp-registration.md` — MCP server registration
  discipline: always `-s user` (global scope), absolute paths in the
  wrapper, never pipe `claude mcp add`, reset both scopes before
  re-adding, restart the host session after register.
- `references/06-language-policy.md` — Public repo artefacts are
  English-only at the time of writing.
- `references/trios-phd-canon.md` — Canonical TRIOS PhD invariants for
  RAG / agent retrieval, including the `TRIOS_PHD_NO_IMAGE_TRAIN` rule
  and the accepted PDF QA baseline.
- `references/qa-brochure-pdf-checklist.md` — Operational pre-publish
  checklist with the current accepted numeric baseline.
- `references/PDF_QA_CHECKLIST.md` — RAG-side PDF QA checklist.
- `references/IMAGE_MANIFEST_SCHEMA.md` — image manifest schema for
  hero / context placement.
- `references/IMAGE_PLACEMENT.md` — placement rules for heroes and
  context images.

## Quickstart — Connect to Claude Code & Print a New GOLDEN CHAIN PDF

Use this when the user asks to wire `trios-mcp-rag` into Claude Code and
produce a fresh GOLDEN CHAIN PDF.

1. **Build or locate the binary.**
   `cargo build --release` (or use the prebuilt `target/release/trios-mcp-rag`).
2. **Put the DSN in `.env`.** Never commit it. Reference it only via
   env-var name (`DATABASE_URL` / `RAILWAY_SSOT_URL`).
3. **Register the MCP server with Claude Code** using a shell wrapper so
   the DSN never lands in Claude's config:

   ```bash
   claude mcp add trios-mcp-rag \
     -- sh -c 'set -a && . ./.env && exec ./target/release/trios-mcp-rag'
   claude mcp list
   ```

   Restart the Claude Code session — MCP tools are loaded at session
   start.
4. **Prerequisites for printing:** `pandoc` + `tectonic` must be on PATH.
5. **Dry run first**, then full build:

   ```bash
   trios-mcp-rag build-pdf --dry-run
   trios-mcp-rag build-pdf \
     --book-mode \
     --out-dir generated/out \
     --pdf-name "GOLDEN_CHAIN_$(date +%F).pdf"
   ```

   Reference baseline build: **88 chapters → 327 pages, ~11 MB, cover
   inserted**, database read **read-only**.
6. **Run the QA checklist** (`references/qa-brochure-pdf-checklist.md`
   and `references/PDF_QA_CHECKLIST.md`) before declaring the build done.

For deeper setup (connection guides, SSOT → PDF pipeline) see the
repository's `README.md` and `docs/rag/` directory directly.
