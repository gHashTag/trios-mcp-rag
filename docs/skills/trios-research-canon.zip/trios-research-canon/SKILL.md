---
name: trios-research-canon
description: "Literature canon backing the trios-mcp-rag operating rules: 4-track research synthesis across (1) TRIOS / S³AI / GOLDEN BRIDGE and adjacent neuro-symbolic / self-supervised reasoning work, (2) RAG over SSOT / structured Postgres sources (Lewis 2020, GraphRAG, RAGAS, pgvector hybrid retrieval, text-to-SQL), (3) claim-status, calibration, and falsifiability for LLM outputs (TruthfulQA, FActScore, FELM, HaluEval, Popperian framing, abstention policies), and (4) reproducible scholarly PDF pipelines (pandoc, tectonic, Quarto, Typst, figure-placement and PDF/UA-2 accessibility literature). Load when answering questions about why a TRIOS rule exists, drafting a new chapter that needs external citation anchoring, evaluating a claim's epistemic status, designing a RAG evaluation harness, or justifying a build / typography decision for the GOLDEN CHAIN PDF. Companion to the trios-mcp-rag skill, which carries the normative rules."
metadata:
  source_repo: https://github.com/gHashTag/trios-mcp-rag
  compiled: '2026-05-29'
  tracks: 4
  word_count: 4100
  version: '1.0'
---

# trios-research-canon — Literature Backing for trios-mcp-rag

This skill is the **literature canon** behind the operating rules of
[gHashTag/trios-mcp-rag](https://github.com/gHashTag/trios-mcp-rag).
It is paired with the **`trios-mcp-rag`** skill, which carries the
normative rules; this skill carries the *why* — the peer-reviewed and
practitioner evidence supporting those rules.

## When to Use This Skill

Load this skill when you need to:

- justify or challenge a rule in `trios-mcp-rag` with cited evidence
- draft a new chapter or PDF section that needs external-citation
  anchoring (Track 1 + Track 3 requirement: no external DOI ⇒ capped at
  Open conjecture)
- design or revise the RAG evaluation harness for `ssot_brochure.chapters`
  (Track 2: RAGAS, GraphRAG, hybrid retrieval)
- evaluate the epistemic status of a claim and pick the right label
  (Track 3: Verified / Empirical fit / Open conjecture / High-risk /
  Retracted, mapped to HaluEval and FActScore taxonomies)
- justify a build, typography, or accessibility decision for the
  GOLDEN CHAIN PDF (Track 4: pandoc / tectonic / Quarto / PDF/UA-2)
- explain to a collaborator why a specific QA gate exists or why a
  proposed shortcut would violate the canon

For the rules themselves and the Quickstart that connects the project
to Claude Code, use the **`trios-mcp-rag`** skill instead.

## How the Canon Is Organised

The full report is in `references/canon-full.md` (≈4,100 words, single
file). It is also split per track for targeted retrieval:

- `references/00-overview.md` — purpose and scope of the canon.
- `references/01-trios-s3ai-adjacent.md` — **Track 1.** A direct
  arXiv / Google Scholar / Semantic Scholar / OpenReview search for
  "TRIOS", "S³AI", "GOLDEN BRIDGE", and `gHashTag` returned **zero
  peer-reviewed publications** as of 2026-05-29. The track instead
  surfaces 8 high-signal adjacent references on neuro-symbolic AI,
  self-supervised reasoning, knowledge-grounded LLMs, and
  textbook-scale AI compendium generation, and explains why each
  applies to this project.
- `references/02-rag-over-ssot.md` — **Track 2.** 10 references
  including Lewis et al. (NeurIPS 2020, foundational RAG), Microsoft
  GraphRAG (arXiv 2404.16130), RAGAS (EACL 2024), pgvector hybrid
  retrieval practitioner guides, KAG, Datrics Text2SQL, BEIR,
  TruLens, and long-context chunking work.
- `references/03-claim-status-calibration.md` — **Track 3.** 10
  references — TruthfulQA (ACL 2022), FActScore (EMNLP 2023), FELM
  (NeurIPS 2023), HaluEval (EMNLP 2023), Xu et al.'s
  hallucination-is-inevitable result, Tomani's abstention policy
  paper, I-CALM, Popper (1963) for falsifiability framing, POPPER
  agentic validation. The track maps the TRIOS five-level scheme
  (Verified / Empirical fit / Open conjecture / High-risk / Retracted)
  onto the HaluEval taxonomy and the FActScore rubric.
- `references/04-reproducible-pdf-pipeline.md` — **Track 4.** 10
  references — pandoc docs, MacFarlane TUG 2020, tectonic book +
  GitHub reproducibility discussion, Quarto figure docs, Mittelbach
  TUGboat 2018 (widows / orphans / penalties), TeX FAQ, Overleaf /
  eSAIL PDF/UA-2 guides, Maedje's TeX-vs-Typst layout analysis.
- `references/05-cross-cutting.md` — **9 cross-cutting
  recommendations** that tie all four tracks back to specific rule
  files (`00-canonical-pipeline.md`, `01-ssot-and-derived-artifacts.md`,
  `02-pdf-style.md`, `03-safety-railway-postgres.md`,
  `04-claim-status.md`, `05-brochure-qa-checklist.md`,
  `06-language-policy.md`, `trios-phd-canon.md`,
  `IMAGE_PLACEMENT.md`, `IMAGE_MANIFEST_SCHEMA.md`,
  `PDF_QA_CHECKLIST.md`).
- `references/canon-full.md` — the full single-file canon.

## Headline Findings (TL;DR)

1. **TRIOS / S³AI / GOLDEN BRIDGE has no external peer-reviewed
   footprint** as of 2026-05-29. The repo cannot rely on its brand
   names for credibility — every algorithmic or empirical claim must
   cite an external DOI from a recognised venue, otherwise it is
   capped at **Open conjecture**.
2. **Hybrid pgvector HNSW + tsvector GIN inside a single Postgres
   instance is production-grade for SSOT-backed RAG.** The existing
   read-only default plus an index-presence pre-build check is enough;
   no external vector store is required.
3. **Hallucinations are provably unavoidable** in the general case
   (Xu et al.). The right response is not "eliminate" but
   *label + abstain + falsification path*. Every Open-conjecture claim
   must carry a written disconfirming observation in the
   `falsification_path` column.
4. **Reproducible PDF builds require neutralising `CreationDate`
   non-determinism and pinning tectonic.** Add a `sha256` of the
   output PDF to the build log; treat a tectonic version bump as a
   pipeline change.
5. **`TRIOS_PHD_NO_IMAGE_TRAIN` is correct, but the implementation
   must be penalty-based**, not `\clearpage`-based:
   `\widowpenalty=9999`, `\clubpenalty=9999`, `\needspace{}` guards,
   and `fig-pos: 'ht'` in YAML. Combined with non-nullable `alt_text`
   in the image manifest, this also satisfies PDF/UA-2 accessibility.

## How to Apply the Canon

When reasoning about a TRIOS task:

1. Identify which track(s) the task touches.
2. Read the matching `references/0X-*.md` file before drafting an
   answer or a build command.
3. Cite the source in your response (use the inline links already in
   the canon — never bare URLs).
4. If the task creates or modifies a claim, pick a label from the
   five-level scheme and, if **Open conjecture**, write the
   falsification path immediately.
5. If the task changes the build pipeline, cross-check against the
   cross-cutting recommendations in `references/05-cross-cutting.md`
   before proposing the change.

## Relationship to Other Skills

- **`trios-mcp-rag`** — the normative rule set. Always load it for any
  TRIOS task. This skill (`trios-research-canon`) is the evidence base
  behind those rules; load it when justifying a decision or writing
  new material.
- **`research-assistant`** (built-in) — use for fresh literature
  searches on topics not yet covered in this canon. Add new findings
  back into `references/literature/` when they are substantive.

*Canon compiled 2026-05-29. Track 1 negative result is dated;
re-verify before citing as evidence in any public artefact.*
